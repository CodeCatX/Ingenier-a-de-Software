% Imprimir tablero %
imprimir_tablero :-
	write('  |  |  '), nl,
	write('--+--+--'), nl,
	write('  |  |  '), nl,
	write('--+--+--'), nl,
	write('  |  |  '), nl.





